<!-- <?php
$servername = "localhost";
$username = "root";
$password = "mysqlpassword";
$dbname = "JonathansTennisDb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Logbook (writer, text)
VALUES ('" . $_POST["name"] . "', '" . $_POST["guestbook-text"] . "')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?> -->

<html>

<head>
    <title>Jonny long schlong</title>
    <link rel="stylesheet" type="text/css" href="./style.css">
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,700,0,0" />
    <script src="./script.js"></script>
</head>

<body>

    <h1>Lieblingsspieler</h1>
    <div class="flex-center">
        <div class="card">
            <img class="card-img"
                src="https://r.testifier.nl/Acbs8526SDKI/resizing_type:fill/watermark:Paul+Zimmer/width:1200/height:800/crop:0.999:0.99/dpr:1/el:1/plain/https%3A%2F%2Fs3-newsifier.ams3.digitaloceanspaces.com%2Ftennisinfinitycom%2Fimages%2F2023-02%2Frublev-andrey-qataropen2023-paulzimmer-63f84e9930890.jpg"
                alt="Avatar" style="width:100%">
            <div class="card-container">
                <h4><b>Andrey Rublev</b></h4>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit at in quam, ut facere quo
                    enim, quos cupiditate eos rem voluptates esse fuga, autem tempore minima harum provident
                    voluptatum obcaecati.</p>
            </div>
        </div>
        <div class="card">
            <img class="card-img" src="https://m.media-amazon.com/images/I/6113jZ5R5oL._AC_UF1000,1000_QL80_.jpg"
                alt="Avatar" style="width:100%">
            <div class="card-container">
                <h4><b>Emma Raducanu</b></h4>
                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Reprehenderit at in quam, ut facere quo
                    enim, quos cupiditate eos rem voluptates esse fuga, autem tempore minima harum provident
                    voluptatum obcaecati.</p>
            </div>
        </div>
    </div>

</body>

</html>