function Lieblingsspielerseite(){
    window.location.href="Lieblingsspieler.php";
}